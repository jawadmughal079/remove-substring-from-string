#include <iostream>
#include <fstream>
int lenght(char array[], int size);
using namespace std;
int main()
{
    int temp1 = 0;
    int temp2 = 0;
    int k = 0;
    int j = 0;
    int counter = 0;
    int q = 0;
    int w = 0;
    int z = 0;
    int lenght1 = 0;
    int lenght2 = 0;
    int size = 1000;
    ifstream read;
    read.open("data.txt");
    char array1[size] = {" "};
    char array2[size] = {" "};
    char array3[size] = {" "};
    char array4[size] = {" "};
    char array5[size] = {" "};
    read.getline(array1, size);
    lenght(array1, size);
    lenght1 = lenght(array1, size);

    read.getline(array2, size);
    lenght2 = lenght(array2, size);
    cout << "\n lenght 1 : ";
    cout << lenght1;
    cout << endl;
    cout << "\n lenght 2 : ";

    char resultant[lenght1];

    cout << lenght2;
    cout << endl;
    for (int i = 0; array1[i] != '\0'; i++)
    {
        k = i;
        for (j = 0; array2[j] != '\0'; j++)
        {
            if (array1[k] != array2[j])
            {
                break;
            }
            k++;
        }
        if (j == lenght2)
        {
            cout << "first index where char found " << i << "   ";
            cout << endl;

            for (int p = 0; p < i; p++)
            {
                resultant[p] = array1[p];
            }
            int p1 = i;
            for (int p = i + lenght2; array1[p] != '\0'; p++)
            {
                resultant[p1] = array1[p];
                p1++;
            }
            resultant[p1] = '\0';

            cout << resultant << endl;

            // copy resultant into array1
            int k;
            for (k = 0; resultant[k] != '\0'; k++)
            {
                array1[k] = resultant[k];
            }
            array1[k] = '\0';

            // counter++;
            // if (counter == 1)
            // {
            //     for (int a = 0; a < i; a++)
            //     {
            //         array3[q++] = array1[a];
            //     }
            //     temp1 = i + lenght2;
            // }
            // if (counter == 2)
            // {
            //     for (int a = i + lenght2; a < lenght1; a++)
            //     {
            //         array4[w++] = array1[a];
            //     }
            //     temp2 = i;
            // }
        }
    }
    // for (int i = temp1; i < temp2; i++)
    // {
    //     array5[z++] = array1[i];
    // }

    // cout << " array 3 :" << array3;
    // cout << endl;
    // cout << " array 5 :" << array5;
    // cout << endl;
    // cout << " array 4 :" << array4;
    // cout << endl;
    // cout << array1;?
    return 0;
}
int lenght(char array[], int size)
{
    int lenght = 0;
    while (array[lenght] != '\0')
    {
        lenght++;
    }
    return lenght;
}

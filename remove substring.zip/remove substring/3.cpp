#include <iostream>
#include <fstream>
using namespace std;
int globalIndex = 0;
int lenght(char array[], int &lenght3);

int main()
{
    int k = 0;
    int j = 0;
    int p = 0;
    int index = 0;
    int lenght1 = 0;
    int lenght2 = 0;
    char string[200] = " ";
    char store[200] = " ";
    char subString[20] = " ";
    ifstream read;
    read.open("data.txt");
    if (read.is_open())
    {
        read.getline(string, 200);
        lenght(string, lenght1);
        read.getline(subString, 20);
        lenght(subString, lenght2);

        for (int i = 0; string[i] != '\0'; i++)
        {
            k = i;
            for (j = 0; subString[j] != '\0'; j++)
            {
                if (string[k] != subString[j])
                {
                    break;
                }
                k++;
            }
            if (j == lenght2)
            {
                for (int l = 0; l < i; l++)
                {
                    store[l] = string[l];
                }
                index = i;
                for (int i = index + lenght2; string[i] != '\0'; i++)
                {
                    store[index++] = string[i];
                }
                store[index] = '\0';
                for (p = 0; store[p] != '\0'; p++)
                {
                    string[p] = store[p];
                }
                string[p] = '\0';
            }
        }
    }
    cout << " STRING IS : ";
    cout << endl;
    cout << string;
    return 0;
}
int lenght(char array[], int &lenght3)
{
    while (array[lenght3] != '\0')
    {
        lenght3++;
    }
}

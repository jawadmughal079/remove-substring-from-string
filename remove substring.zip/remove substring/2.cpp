#include <iostream>
#include <fstream>
using namespace std;
void lenghtFinder(char array[], int &lenght);
int main()
{
    int k = 0;
    int j = 0;
    int lenght1 = 0;
    int lenght2 = 0;
    ifstream read;
    read.open("sentence.txt");
    char string[200] = " ";
    char reserve[200] = " ";
    read.getline(string, 200);
    lenghtFinder(string, lenght1);
    char subString[10] = " ";
    read.getline(subString, 20);
    lenghtFinder(subString, lenght2);
    for (int i = 0; string[i] != '\0'; i++)
    {
        k = i;
        for (j = 0; subString[j] != '\0'; j++)
        {
            if (string[k] != subString[j])
            {
                break;
            }
            k++;
        }
        if (j == lenght2)
        {

            cout << i << " ";
            // for (int l = 0; l < i; l++)
            // {
            //     reserve[l] = string[l];
            // }
            // int q = i;
            // for (int l = i + lenght2; string[l] != '\0'; l++)
            // {
            //     reserve[q++] = string[l];
            // }
            // reserve[q] = '\0';
            // int m = 0;
            // for (m = 0; reserve[m] != '\0'; m++)
            // {
            //     string[m] = reserve[m];
            // }
            // string[m] = '\0';
        }
    }
    // cout << reserve;
    return 0;
}
void lenghtFinder(char array[], int &lenght)
{

    while (array[lenght] != '\0')
    {
        lenght++;
    }
}